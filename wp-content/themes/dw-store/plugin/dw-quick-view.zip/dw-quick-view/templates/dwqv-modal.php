<div id="dwqv-modal">

	<div class="dwqv-overlay"></div>

	<div class="dwqv-wrapper">

		<div class="dwqv-main">

			<div class="dwqv-head">
				<a href="#" id="dwqv-close" class="dwqv-close">&times;</a>
			</div>

			<div id="dwqv-content" class="woocommerce single-product"></div>

		</div>

	</div>

</div>