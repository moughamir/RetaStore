<?php if (!defined('FW')) die('Forbidden');
require_once 'slides/class-fw-option-type-slides.php';
