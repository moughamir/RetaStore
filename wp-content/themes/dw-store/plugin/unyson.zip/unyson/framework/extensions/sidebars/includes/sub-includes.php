<?php if (!defined('FW')) die('Forbidden');

$curr_dir = dirname(__FILE__);

require $curr_dir .'/model/class-fw-extension-sidebars-model-sidebar.php';
require $curr_dir .'/option-type/sidebar-picker/class-fw-option-type-sidebar-picker.php';
require $curr_dir .'/option-type/sidebar-picker/class-fw-sidebar-picker-option-handler.php';
