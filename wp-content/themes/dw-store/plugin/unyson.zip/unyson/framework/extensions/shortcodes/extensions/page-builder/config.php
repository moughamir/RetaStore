<?php if (!defined('FW')) die('Forbidden');

$cfg = array();

$cfg['disable_correction'] = false;
