<?php if (!defined('FW')) die('Forbidden');

$manifest = array();

$manifest['name']        = __( 'Nivo Slider', 'fw' );
$manifest['description'] = __( 'Nivo Slider', 'fw' );
$manifest['version'] = '1.0.0';
$manifest['display'] = 'slider';
$manifest['standalone'] = true;