<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}
/**
 * @var string $form_id
 * @var string $form_html
 */
?>
<div class="form-wrapper contact-form">
	<?php echo $form_html; ?>
</div>